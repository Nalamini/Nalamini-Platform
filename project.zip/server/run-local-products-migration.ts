// This is a simple wrapper to run the local products architecture migration
import "./migrate-local-products-architecture";