// This file is just a wrapper to run the migration script
import './migrate-farmer-listings';