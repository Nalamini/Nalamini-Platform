# Nalamini Service Platform API

Minimal API deployment for Nalamini Service Platform.

## API Endpoints

- `/api` - Base API endpoint that returns service status